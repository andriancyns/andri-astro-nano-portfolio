---
title: "Year sorting example"
description: "Nano groups posts by year."
date: "12/31/2023"
---

This post is to demonstrate the year sorting capabilities.